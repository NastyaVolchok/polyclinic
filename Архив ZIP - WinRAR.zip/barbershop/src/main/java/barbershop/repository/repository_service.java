package barbershop.repository;

import barbershop.model.Service;
import org.springframework.data.jpa.repository.JpaRepository;

public interface repository_service extends JpaRepository<Service,Integer> {
}
