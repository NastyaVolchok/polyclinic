package barbershop.repository;

import barbershop.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface repository_employee extends JpaRepository<Employee,Integer> {
}
