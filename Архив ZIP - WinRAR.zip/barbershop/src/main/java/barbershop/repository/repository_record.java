package barbershop.repository;

import barbershop.model.Records;
import org.springframework.data.jpa.repository.JpaRepository;

public interface repository_record extends JpaRepository<Records,Integer> {
}
