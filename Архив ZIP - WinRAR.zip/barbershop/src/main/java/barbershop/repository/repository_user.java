package barbershop.repository;

import barbershop.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface repository_user extends JpaRepository<User,Integer> {
}
