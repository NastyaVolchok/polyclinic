package barbershop.repository;

import barbershop.model.Ban_list;
import org.springframework.data.jpa.repository.JpaRepository;

public interface repository_Ban_list extends JpaRepository<Ban_list,Integer> {
}
