package barbershop.repository;

import barbershop.model.History;
import org.springframework.data.jpa.repository.JpaRepository;

public interface repository_history extends JpaRepository<History,Integer> {
}
